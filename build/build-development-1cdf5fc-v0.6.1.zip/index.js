/**!
 * Built: Mon Jun 15 2015 08:47:37 GMT+0200 (CEST)
 * Environment: development
 * Mode: console
 * Version: 0.6.1
 * Revision: 1cdf5fc
 * Branch: feature/build-system
 * Tag: v0.6.1
 **/
require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){


},{}],"AtomButton":[function(require,module,exports){
function demoIndex() {
	console.log('I am from the index!');
}

module.exports = demoIndex;

},{}],"AtomsButton":[function(require,module,exports){
arguments[4]["AtomButton"][0].apply(exports,arguments)
},{"dup":"AtomButton"}],"MoleculesButtonRow":[function(require,module,exports){
var atomButton = require('atom-button');

function demoDependencies() {
	atomButton();
	console.log('I should print things from atom-button.index')
}

module.exports = demoDependencies;

},{"atom-button":"atom-button"}],"OrganismsTest":[function(require,module,exports){
require('button-row');
require('AtomButton');

},{"AtomButton":"AtomButton","button-row":"button-row"}],"atom-button":[function(require,module,exports){
arguments[4]["AtomButton"][0].apply(exports,arguments)
},{"dup":"AtomButton"}],"atom-button":[function(require,module,exports){
arguments[4]["AtomButton"][0].apply(exports,arguments)
},{"dup":"AtomButton"}],"button-row":[function(require,module,exports){
arguments[4]["MoleculesButtonRow"][0].apply(exports,arguments)
},{"atom-button":"atom-button","dup":"MoleculesButtonRow"}]},{},[1])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJfc3RyZWFtXzAuanMiLCJwYXR0ZXJucy9hdG9tcy9idXR0b24vX3N0cmVhbV82LmpzIiwicGF0dGVybnMvbW9sZWN1bGVzL2J1dHRvbi1yb3cvX3N0cmVhbV8zLmpzIiwicGF0dGVybnMvb3JnYW5pc21zL3Rlc3QvX3N0cmVhbV83LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUNMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDUkE7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIlxuIiwiZnVuY3Rpb24gZGVtb0luZGV4KCkge1xuXHRjb25zb2xlLmxvZygnSSBhbSBmcm9tIHRoZSBpbmRleCEnKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBkZW1vSW5kZXg7XG4iLCJ2YXIgYXRvbUJ1dHRvbiA9IHJlcXVpcmUoJ2F0b20tYnV0dG9uJyk7XG5cbmZ1bmN0aW9uIGRlbW9EZXBlbmRlbmNpZXMoKSB7XG5cdGF0b21CdXR0b24oKTtcblx0Y29uc29sZS5sb2coJ0kgc2hvdWxkIHByaW50IHRoaW5ncyBmcm9tIGF0b20tYnV0dG9uLmluZGV4Jylcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBkZW1vRGVwZW5kZW5jaWVzO1xuIiwicmVxdWlyZSgnYnV0dG9uLXJvdycpO1xucmVxdWlyZSgnQXRvbUJ1dHRvbicpO1xuIl19
